package com.example.hokiemoneymanager

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hokiemoneymanager.databinding.FragmentExpensesBinding
import com.example.hokiemoneymanager.databinding.FragmentIncomeBinding

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Expenses.newInstance] factory method to
 * create an instance of this fragment.
 */
class Expenses : Fragment() {
    private lateinit var  binding: FragmentExpensesBinding
    private lateinit var adapter: ExpensesAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentExpensesBinding.inflate(layoutInflater)
        adapter = ExpensesAdapter()
        binding?.expenseRecyclerView?.adapter = adapter
        binding?.expenseRecyclerView?.layoutManager = LinearLayoutManager(binding?.root?.context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        inflater.inflate(R.layout.fragment_expenses, container, false)
        return binding?.root
    }

    inner class ExpensesAdapter: RecyclerView.Adapter<ExpensesAdapter.ExpensesViewHolder>(){

//        private var expenses = emptyList<ExpensesItem>()
private var expenses = listOf(
    ExpensesItem("Groceries", 150.0),
    ExpensesItem("Rent", 800.0),
    ExpensesItem("Utilities", 100.0),
    ExpensesItem("Internet", 50.0),
    ExpensesItem("Transportation", 75.0),
    ExpensesItem("Dining Out", 120.0),
    ExpensesItem("Gym Membership", 40.0),
    ExpensesItem("Entertainment", 60.0),
    ExpensesItem("Clothing", 100.0),
    ExpensesItem("Healthcare", 80.0)
)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpensesViewHolder {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_card_view, parent, false)
            return ExpensesViewHolder(v)
        }

        override fun getItemCount(): Int {
            return expenses.size
        }

        override fun onBindViewHolder(holder: ExpensesViewHolder, position: Int) {
            holder.view?.findViewById<TextView>(R.id.source)?.text = expenses[position].expenseSource
            holder.view?.findViewById<TextView>(R.id.amount)?.text = expenses[position].amount.toString()
            holder.view?.setOnClickListener {
                findNavController().navigate((R.id.action_expenses_to_expensesAccountTransactions))
            }
        }

        inner class ExpensesViewHolder(val view: View?): RecyclerView.ViewHolder(view!!),View.OnClickListener
        {
            override fun onClick(v: View?) {
                Log.d("Income", "list tap ")
                if (view != null) {
                    //Do some stuff here after the tap
                    findNavController().navigate(R.id.action_expenses_to_expensesAccountTransactions)
                }
            }
        }
    }


}