package com.example.hokiemoneymanager

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hokiemoneymanager.databinding.FragmentIncomeAccountTransactionsBinding
import com.example.hokiemoneymanager.databinding.MonthCardViewBinding
import com.example.hokiemoneymanager.databinding.MonthCardViewItemBinding

class IncomeAccountTransactions : Fragment() {
    private var detailedIncome: FragmentIncomeAccountTransactionsBinding? = null
    private lateinit var viewAdapter: DetailedIncomeRVAdapter
    private val months = ArrayList<Month>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        detailedIncome =
            FragmentIncomeAccountTransactionsBinding.inflate(inflater, container, false)
        initMonthsArray(months)
        detailedIncome!!.monthCardViews.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        viewAdapter = DetailedIncomeRVAdapter(months)
        detailedIncome!!.monthCardViews.adapter = viewAdapter

        return detailedIncome?.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        detailedIncome = null
    }

    private fun initMonthsArray(months: MutableList<Month>) {
        months.clear()
        months.add(
            Month(
                "January",
                Color.GRAY,
                arrayListOf(
                    MonthItem("Student 01", 70.0),
                    MonthItem("Student 02", 40.0),
                    MonthItem("Student 03", 100.0)
                )
            )
        )
        months.add(Month("February", Color.YELLOW, arrayListOf()))
        months.add(Month("March", Color.WHITE, arrayListOf()))
        months.add(Month("April", Color.MAGENTA, arrayListOf()))
        months.add(Month("May", Color.RED, arrayListOf()))
    }
}

class DetailedIncomeRVAdapter(private val months: ArrayList<Month>) :
    RecyclerView.Adapter<DetailedIncomeRVAdapter.ViewHolder>() {

    class ViewHolder(private val binding: MonthCardViewBinding, context: Context) :
        RecyclerView.ViewHolder(binding.root) {
        private val subAdapter = DetailedIncomeItemsRVAdapter(arrayListOf())
        private val layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)

        init {
            binding.monthCardViewItems.layoutManager = layoutManager
            binding.monthCardViewItems.adapter = subAdapter
        }

        fun bindItems(month: Month) {
            binding.monthText.text = month.monthName
//            binding.cardWidget.setBackgroundColor(month.color)
            subAdapter.monthItems = month.monthItems
            subAdapter.notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val context = parent.context

        val binding =
            MonthCardViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, context)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItems(months[position])
    }

    override fun getItemCount() = months.size
}

class DetailedIncomeItemsRVAdapter(var monthItems: ArrayList<MonthItem>) :
    RecyclerView.Adapter<DetailedIncomeItemsRVAdapter.ViewHolder>() {
    class ViewHolder(private val binding: MonthCardViewItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bindItems(monthItem: MonthItem) {
            binding.firstColumn.text = monthItem.itemName
            binding.secondColumn.text = monthItem.itemPrice.toString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            MonthCardViewItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItems(monthItems[position])
    }

    override fun getItemCount() = monthItems.size
}