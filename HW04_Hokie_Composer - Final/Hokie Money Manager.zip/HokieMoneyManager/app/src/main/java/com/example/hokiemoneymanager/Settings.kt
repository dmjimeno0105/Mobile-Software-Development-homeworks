package com.example.hokiemoneymanager

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.hokiemoneymanager.databinding.FragmentSettingsBinding
import android.widget.ArrayAdapter
import org.json.JSONObject
import java.io.IOException



/**
 * A simple [Fragment] subclass.
 * Use the [Settings.newInstance] factory method to
 * create an instance of this fragment.
 */
class Settings : Fragment() {
    private lateinit var binding: FragmentSettingsBinding
    private val model: ViewModel by activityViewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentSettingsBinding.inflate(layoutInflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnNavigateToProfile = view.findViewById<Button>(R.id.btnViewProfile)
        btnNavigateToProfile.setOnClickListener {
            findNavController().navigate(R.id.action_settings_to_profileFragment)
        }

        binding.switchCurrency.setOnCheckedChangeListener { _, isChecked ->
            // Handle the checked change event
            if (isChecked) {
                // The switch is on

                model.locationChanged()
                val text = model.locationEnabled.value.toString()
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(context, text, duration) // in Activity
                toast.show()
            } else {
                model.locationChanged()
                val text = model.locationEnabled.value.toString()
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(context, text, duration) // in Activity
                toast.show()
            }
        }

        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.currency_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->        // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)        // Apply the adapter to the spinner
            binding.spinnerCurrency.adapter = adapter
        }
        binding.spinnerCurrency.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    val selectedItem = parent.getItemAtPosition(position).toString()
                    val value = getValueFromJson(selectedItem)
                    model.setCountryName(selectedItem)

                    model.setCountrySymbol(value)

                    model.countrySymbol.observe(viewLifecycleOwner) { countrySymbol ->
                        model.setExchangeRate(value)
                        countrySymbol?.let {
                            Log.d("Settings.kt countrySymbol", model.countrySymbol.value.toString())
                            Log.d("Settings.kt exchangeRate", model.exchangeRate.value.toString())
                        }
                    }
                    Toast.makeText(context, value, Toast.LENGTH_SHORT).show()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    TODO("Not yet implemented")
                }
            }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        inflater.inflate(R.layout.fragment_settings, container, false)
        return binding?.root
    }

    private fun getValueFromJson(selectedItem: String): String {
        val jsonString = loadJSONFromAsset()
        val jsonObject = JSONObject(jsonString)
        return jsonObject.optString(selectedItem, "Not found")
    }

    private fun loadJSONFromAsset(): String {
        val json: String?
        try {
            val inputStream = context?.assets?.open("Countries.json")
            json = inputStream?.bufferedReader().use { it?.readText() }
        } catch (ex: IOException) {
            ex.printStackTrace()
            return ""
        }
        return json ?: ""
    }
}