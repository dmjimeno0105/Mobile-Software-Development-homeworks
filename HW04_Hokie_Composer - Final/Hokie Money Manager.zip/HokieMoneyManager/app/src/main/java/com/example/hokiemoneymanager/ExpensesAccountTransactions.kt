package com.example.hokiemoneymanager

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hokiemoneymanager.databinding.FragmentExpensesAccountTransactionsBinding
import com.example.hokiemoneymanager.databinding.MonthCardViewBinding
import com.example.hokiemoneymanager.databinding.MonthCardViewItemBinding

class ExpensesAccountTransactions : Fragment() {
    private var detailedExpenses: FragmentExpensesAccountTransactionsBinding? = null
    private lateinit var viewAdapter: DetailedIncomeRVAdapter
    private val months = ArrayList<Month>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        detailedExpenses =
            FragmentExpensesAccountTransactionsBinding.inflate(inflater, container, false)
        initMonthsArray(months)
        detailedExpenses!!.monthCardViews.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        viewAdapter = DetailedIncomeRVAdapter(months)
        detailedExpenses!!.monthCardViews.adapter = viewAdapter

        return detailedExpenses?.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        detailedExpenses = null
    }

    private fun initMonthsArray(months: MutableList<Month>) {
        months.clear()
        months.add(
            Month(
                "January",
                Color.GRAY,
                arrayListOf(
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0)
                )
            )
        )
        months.add(
            Month(
                "February", Color.YELLOW,
                arrayListOf(
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Gas", 20.0),
                    MonthItem("Groceries", 10.0),
                    MonthItem("Dining", 15.0),
                    MonthItem("Mjolnir", 1000.0),
                    MonthItem("Mjolnir", 1000.0)
                )
            )
        )
        months.add(Month("March", Color.WHITE, arrayListOf(
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Gas", 20.0),
            MonthItem("Groceries", 10.0),
            MonthItem("Dining", 15.0),
            MonthItem("Mjolnir", 1000.0),
            MonthItem("Mjolnir", 1000.0)
        )))
        months.add(Month("April", Color.MAGENTA, arrayListOf()))
        months.add(Month("May", Color.RED, arrayListOf()))
    }
}

class DetailedExpensesRVAdapter(private val months: ArrayList<Month>) :
    RecyclerView.Adapter<DetailedExpensesRVAdapter.ViewHolder>() {

    class ViewHolder(private val binding: MonthCardViewBinding, context: Context) :
        RecyclerView.ViewHolder(binding.root) {
        private val subAdapter = DetailedExpensesItemsRVAdapter(arrayListOf())
        private val layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)

        init {
            binding.monthCardViewItems.layoutManager = layoutManager
            binding.monthCardViewItems.adapter = subAdapter
        }

        fun bindItems(month: Month) {
            binding.monthText.text = month.monthName
//            binding.cardWidget.setBackgroundColor(month.color)
            subAdapter.monthItems = month.monthItems
            subAdapter.notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val context = parent.context

        val binding =
            MonthCardViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, context)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItems(months[position])
    }

    override fun getItemCount() = months.size
}

class DetailedExpensesItemsRVAdapter(var monthItems: ArrayList<MonthItem>) :
    RecyclerView.Adapter<DetailedExpensesItemsRVAdapter.ViewHolder>() {
    class ViewHolder(private val binding: MonthCardViewItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bindItems(monthItem: MonthItem) {
            binding.firstColumn.text = monthItem.itemName
            binding.secondColumn.text = monthItem.itemPrice.toString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            MonthCardViewItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItems(monthItems[position])
    }

    override fun getItemCount() = monthItems.size
}