package com.example.hokiemoneymanager

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hokiemoneymanager.databinding.FragmentIncomeBinding


class Income : Fragment() {
    private lateinit var binding: FragmentIncomeBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter:IncomeAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentIncomeBinding.inflate(layoutInflater)
        adapter = IncomeAdapter()
        binding?.income?.adapter = adapter
        binding?.income?.layoutManager = LinearLayoutManager(binding?.root?.context)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        inflater.inflate(R.layout.fragment_income, container, false)
        return binding?.root
    }

    inner class IncomeAdapter: RecyclerView.Adapter<IncomeAdapter.IncomeViewHolder>(){

//        private var income = emptyList<IncomeItem>()
private var income = listOf(
    IncomeItem("Tutor", 120.0),
    IncomeItem("TA", 800.0),
    IncomeItem("Dining", 60.5),
    IncomeItem("Freelancing", 200.0),
    IncomeItem("Part-Time Job", 300.0),
    IncomeItem("Babysitting", 150.0),
    IncomeItem("Photography", 400.0),
    IncomeItem("Online Sales", 250.0),
    IncomeItem("Dog Walking", 100.0),
    IncomeItem("Gardening", 90.0)
)


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncomeViewHolder {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.single_card_view, parent, false)
            return IncomeViewHolder(v)
        }

        override fun getItemCount(): Int {
            return income.size
        }

        override fun onBindViewHolder(holder: IncomeViewHolder, position: Int) {
            holder.view?.findViewById<TextView>(R.id.source)?.text = income[position].incomeSource
            holder.view?.findViewById<TextView>(R.id.amount)?.text = "$" + income[position].amount.toString()
            holder.view?.setOnClickListener{
                findNavController().navigate(R.id.action_income_to_incomeAccountTransactions)
            }
        }

        inner class IncomeViewHolder(val view: View?): RecyclerView.ViewHolder(view!!),View.OnClickListener
        {
            override fun onClick(v: View?) {
                Log.d("Income", "list tap ")
                if (view != null) {
                    //Do some stuff here after the tap
//                    findNavController().navigate(R.id.action_income_to_incomeAccountTransactions)
                }
            }
        }
    }

}