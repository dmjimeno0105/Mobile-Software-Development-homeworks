package com.example.hokiemoneymanager

data class MonthItem(var itemName: String, var itemPrice: Double)
