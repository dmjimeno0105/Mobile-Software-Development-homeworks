package com.example.hokiemoneymanager

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import edu.vt.cs3714.retrofitrecyclerviewguide.RetrofitService
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.math.BigDecimal

class ViewModel : ViewModel() {
    private val apiKey = "c73d9c228b7b09ff34329d3e95fe8f77"
    private val apiBaseUrl = "http://data.fixer.io/api/" // latest?access_key=

    private val _locationEnabled = MutableLiveData<Boolean>()
    val locationEnabled: LiveData<Boolean> = _locationEnabled

    private val _countryName: MutableLiveData<String> = MutableLiveData()
    var countryName: LiveData<String> = _countryName

    private val _countrySymbol: MutableLiveData<String> = MutableLiveData()
    var countrySymbol: LiveData<String> = _countrySymbol

    private val _currency: MutableLiveData<BigDecimal> = MutableLiveData()
    val currency: LiveData<BigDecimal> = _currency

    private val _exchangeRate: MutableLiveData<BigDecimal?> = MutableLiveData()
    val exchangeRate: LiveData<BigDecimal?> /*get()*/ = _exchangeRate
//    var theExchangeRate: BigDecimal = 1.toBigDecimal()

    private val currencySymbol: MutableLiveData<String> = MutableLiveData()

    private val _balance: MutableLiveData<BigDecimal> = MutableLiveData()
    var balance: LiveData<BigDecimal> /*get()*/ = _balance
//    val theBal: BigDecimal = 70.toBigDecimal()

    private var disposable: Disposable? = null

//    private val localesData = loadLocalesData()

    fun setCountryName(countryName: String) {
        _countryName.value = countryName
    }

//    private fun loadLocalesData(): Map<String, String> {
//        val gson = Gson()
//        FileReader("assets/Countries.json").use { reader ->
//            val type = object : TypeToken<Map<String, String>>() {}.type
//            return gson.fromJson(reader, type)
//        }
//    }
//
//    fun formatCurrency(value: BigDecimal, countryName: String): String {
//        val locale = findLocaleByCountry(countryName)
//        val currencyFormat = NumberFormat.getCurrencyInstance(locale)
//        return currencyFormat.format(value)
//    }
//
//    private fun findLocaleByCountry(countryName: String): Locale {
//        val currencyCode = localesData[countryName] ?: return Locale.US
//
//        return when (currencyCode) {
//            "USD" -> Locale.US
//            "JPY" -> Locale.JAPAN
//            "GBP" -> Locale.UK
//            "CNY" -> Locale.CHINA
//            "AUD" -> Locale("en", "AU")
//            "CAD" -> Locale.CANADA
//            "CHF" -> Locale("de", "CH")
//            "HKD" -> Locale("zh", "HK")
//            "SGD" -> Locale("en", "SG")
//            "SEK" -> Locale("sv", "SE")
//            "KRW" -> Locale.KOREA
//            "NOK" -> Locale("no", "NO")
//            "NZD" -> Locale("en", "NZ")
//            "INR" -> Locale("en", "IN")
//            "MXN" -> Locale("es", "MX")
//            "TWD" -> Locale("zh", "TW")
//            "ZAR" -> Locale("en", "ZA")
//            "BRL" -> Locale("pt", "BR")
//            "DKK" -> Locale("da", "DK")
//            else -> Locale.US
//        }
//    }

    fun setBalance(balance: BigDecimal) {
        _balance.value = balance
    }

    fun setCountrySymbol(value: String) {
        _countrySymbol.value = value
    }

    fun setExchangeRate(countrySymbol: String) {
        disposable =
            RetrofitService.create(apiBaseUrl).getCurrencyExchangeRate(apiKey)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ currency ->
                    Log.d("ViewModel.kt currency (gson)", currency.toString())
//                    val usRate = currency.rates["USD"]
                    val rate = currency.rates[countrySymbol]
                    if (rate != null) {
                        _exchangeRate.value = rate

                        Log.d("API test", _exchangeRate.value.toString())
                    } else {
                        println("Rate for currency $countrySymbol not found.")
                    }
                }, { error ->
                    Log.e("API Error", "Error fetching currency exchange rate", error)
                })
    }

    fun locationChanged() {
        // Check if the current value is null and set a default value in that case
        val currentValue = _locationEnabled.value ?: false
        _locationEnabled.value = !currentValue
    }
//    init {
//        _balance.value = theBal
//        _exchangeRate.value = theExchangeRate
//
//    }
//    private val _audioFileName = MutableLiveData<String>()
//    val audioFileName: LiveData<String> = _audioFileName
//
//    fun setAudioFileName(fileName: String) {
//        _audioFileName.value = fileName
//    }
}



