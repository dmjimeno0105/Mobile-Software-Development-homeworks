package com.example.hokiemoneymanager

data class ExpensesItem(val expenseSource: String, val amount: Double)