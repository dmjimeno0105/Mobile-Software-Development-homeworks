package com.example.hokiemoneymanager

import com.example.hokiemoneymanager.R
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.hokiemoneymanager.databinding.FragmentLandingPageBinding
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.navigation.NavigationView


/**
 * LandingPage fragment class
 */
class LandingPage : Fragment() {
    private lateinit var binding: FragmentLandingPageBinding
    private var drawerLayout: DrawerLayout? = null
    private var toggle: ActionBarDrawerToggle? = null
    private val model: ViewModel by activityViewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLandingPageBinding.inflate(layoutInflater)

        val toolbar: MaterialToolbar? = binding?.toolbar
        (activity as AppCompatActivity).setSupportActionBar(toolbar)

        drawerLayout = binding?.drawerLayout
        toggle = ActionBarDrawerToggle(
            activity, drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout?.addDrawerListener(toggle!!)
        toggle!!.syncState()

        model.setBalance(80.toBigDecimal())
//        model.exchangeRate.observe(viewLifecycleOwner) { exchangeRate ->
//            model.formatCurrency(model.balance.value?.times(exchangeRate!!), model.countryName.value)
//            binding?.balanceValue?.text = (model.balance.value?.times(exchangeRate!!)).toString()
//            Log.d("LandingPage.kt balanceValue", binding?.balanceValue?.text.toString())
//        }

        model.exchangeRate.observe(viewLifecycleOwner) { exchangeRate ->
            val formattedCurrency = model.balance.value?.times(exchangeRate!!)
//                ?.let { model.countryName.value?.let { it1 -> model.formatCurrency(it, it1) } }

            binding?.balanceValue?.text = formattedCurrency.toString()
            Log.d("LandingPage.kt balanceValue", binding?.balanceValue?.text.toString())
        }

        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val navigationView: NavigationView? = binding?.navView
        navigationView?.setNavigationItemSelectedListener { menuItem ->
            Log.d("MainActivity", "Menu item clicked: ${menuItem.itemId}")
            // Handle menu item clicks here
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    findNavController().navigate(R.id.landingPage)
                }

                R.id.nav_settings -> {
                    findNavController().navigate(R.id.action_landingPage_to_settings)
                }
                // Handle other items...
                R.id.nav_Expenses -> {
                    findNavController().navigate(R.id.action_landingPage_to_expenses)
                }

                R.id.nav_Income -> {
                    findNavController().navigate(R.id.action_landingPage_to_income)
                }
            }

            drawerLayout?.closeDrawer(GravityCompat.START)
            true
        }

        binding?.incomeValue?.setOnClickListener {
            findNavController().navigate(R.id.action_landingPage_to_income)

        }

        binding?.expensesValue?.setOnClickListener {
            findNavController().navigate(R.id.action_landingPage_to_expenses)
        }
    }
}