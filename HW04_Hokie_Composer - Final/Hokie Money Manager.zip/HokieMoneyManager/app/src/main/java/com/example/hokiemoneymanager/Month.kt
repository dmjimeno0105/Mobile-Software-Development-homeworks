package com.example.hokiemoneymanager

data class Month(var monthName: String, var color: Int, var monthItems: ArrayList<MonthItem>)

