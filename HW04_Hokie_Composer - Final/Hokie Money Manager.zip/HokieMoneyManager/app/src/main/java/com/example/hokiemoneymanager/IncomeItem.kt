package com.example.hokiemoneymanager

data class IncomeItem(val incomeSource: String,val amount: Double)