Group 19 - HokieMoneyManager:
- Nathan Damte (nathand)
- Dominic Jimeno (dmjimeno0105)
- Dhruv Varsheny (dhruvvarshney)